This lab looks at a hmeq databse with info on loans, and uses it to train a model to predict whether or not a person will default on their loans. 

# lab6-356
The instructions are in the Jupyter notebook. Make your notebook neat and organized with explanations for your code and plots.
