In this lab I tried to perform various types of regression on my data, answered questions on regression, and added a section on logistic regression. 

# lab5-356
For Lab 5, 
1. answer the questions inside of the regression jupyter notebook in this repo. We will add a section on logistic regression to it in class on Thursday.
2. For most of you, you have enough columns of data in your projects that you can perform linear regression analysis in further depth as shown in the notebook. Choose appropriate columns that have good correlations that you can model, and compute MSE or RMSE and interpret your results. Create attractive plots that show your results. If you are one of the few groups who does not have columns of continuous data, find the appropriate metrics used for your type of analysis, and write up a description of them, and how they are used, and if possible, implement them.
